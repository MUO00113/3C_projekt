package com.example.objekt_lebensmittel_verwaltung;

public interface OnSelectionChangedListener {
    void onSelectionChanged(int pos, String itemname);
}
