package com.example.objekt_lebensmittel_verwaltung;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ObjektListeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_objekt_liste);
    }
}